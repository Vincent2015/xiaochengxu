//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    motto: '系统日志',
    userInfo: {}
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../list/list'
    })
  },
  bindViewTapReader: function() {
    wx.navigateTo({
      url: '../home/home'
    })
  },
  onLoad: function () {
   var that = this;
   console.log('onLoad')
    //调用应用实例的方法获取全局数据
    app.getUserInfo(function(userInfo){
      //更新数据
      that.setData({
        userInfo:userInfo
      })
    })
  },
   onShareAppMessage: function () {
    return {
      title: '早读汇',
      path: '/page/user?id=123',
      success: function(res) {
        // 分享成功
      },
      fail: function(res) {
        // 分享失败
      }
    }
  }
})
